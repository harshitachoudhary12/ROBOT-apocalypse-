<!DOCTYPE html>
<html>
<body>

<h2>Export Robot  data</h2>

<form action="<?php echo e(route('upload-json-data-db')); ?>" method="post">
	<?php echo csrf_field(); ?>
  <label for="fname">Json File:</label><br>
  <input type="file" id="json_file" name="json_file" required="">
  <br>
  <br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>

<?php /**PATH C:\xampp\htdocs\secure_layer_7_job_task\resources\views/json_data.blade.php ENDPATH**/ ?>